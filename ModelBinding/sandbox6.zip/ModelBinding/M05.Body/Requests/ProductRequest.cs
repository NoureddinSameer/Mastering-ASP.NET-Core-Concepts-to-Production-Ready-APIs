namespace M05.Body.Requests;

public class ProductRequest
{
    public string? Name { get; set; }
    public decimal Price { get; set; }
}
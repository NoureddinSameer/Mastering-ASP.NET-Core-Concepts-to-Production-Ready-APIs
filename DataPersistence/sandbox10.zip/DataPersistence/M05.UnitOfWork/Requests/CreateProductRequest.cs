namespace M05.UnitOfWork.Requests;

public class CreateProductRequest
{
    public string? Name { get; set; }
    public decimal Price { get; set; }
}

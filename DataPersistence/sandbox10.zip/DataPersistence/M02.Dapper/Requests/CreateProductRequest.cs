namespace M02.Dapper.Requests;

public class CreateProductRequest
{
    public string? Name { get; set; }
    public decimal Price { get; set; }
}

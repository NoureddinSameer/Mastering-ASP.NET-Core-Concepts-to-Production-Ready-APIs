namespace M05.BuildingRESTFulAPI.Requests;

public class UpdateProductRequest
{
    public string? Name { get; set; }
    public decimal? Price { get; set; }
}
